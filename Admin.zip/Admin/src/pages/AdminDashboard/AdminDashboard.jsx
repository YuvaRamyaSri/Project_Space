import React, { useEffect } from "react";
import { useState } from "react";
import { connect } from "react-redux";
import {
    Row,
    Col,
    Card,
    CardBody
} from "reactstrap"
import Miniwidget from "pages/Dashboard/Miniwidget";
import MyChart from "./MyChart"
import CountUp from "react-countup";
import axios from "axios";

//Import Action to copy breadcrumb items from local state to redux state

import { setBreadcrumbItems } from "../../store/actions";
import PieChart from "./PieCharts";
const Admindashboard = () => {
    const [totalPlacements, setTotalPlacements] = useState(0);
    const [highestPackage, setHighestPackage] = useState(0);
    const [technologyCounts, setTechnologyCounts] = useState([]);
    const [codingCounts, setcodingCounts] = useState([]);
    const [totalCompanies, setTotalCompanies] = useState(0);
    const [mostCommonCompany, setMostCommonCompany] = useState("");

    async function fetchPlacementInfo() {
        try {
            const response = await axios.get("http://localhost:5000/totalcount");
            const { totalPlacements, highestPackage } = response.data;
            setTotalPlacements(totalPlacements);
            setHighestPackage(parseFloat(highestPackage));
        } catch (error) {
            console.error("Error fetching placement information:", error);
        }
    }
    async function fetchCompanyStats() {
        try {
            const response = await axios.get("http://localhost:5000/companyStats");
            const mostCommonCompany = response.data.mostCommonCompany[0]; // Access the first element of the array
            setTotalCompanies(mostCommonCompany.count);
            setMostCommonCompany(mostCommonCompany._id);
        } catch (error) {
            console.error("Error fetching company stats:", error);
        }
    }
    async function fetchTechnologyCounts() {
        try {
            const response = await axios.get("http://localhost:5000/technologyCount");
            setTechnologyCounts(response.data);
        } catch (error) {
            console.error("Error fetching technology counts:", error);
        }
    }
    async function fetchCodingCounts() {
        try {
            const response = await axios.get("http://localhost:5000/technologyCountsSeparate");
            setcodingCounts(response.data);
        } catch (error) {
            console.error("Error fetching technology counts:", error);
        }
    }

    useEffect(() => {
        fetchPlacementInfo();
        fetchTechnologyCounts();
        fetchCodingCounts();
        fetchCompanyStats();
    }, []);
    const reports = [
        { title: "Total Placements", iconClass: "cube-outline", total: totalPlacements, badgecolor: "info" },
        { title: "Highest Package", iconClass: "buffer", total: highestPackage, average: "", badgecolor: "danger" },
        { title: "Top Recuriters", iconClass: "tag-text-outline", total: mostCommonCompany, average: "", badgecolor: "warning" },
        { title: "Mnc's Visited", iconClass: "briefcase-check", total: totalCompanies, average: "", badgecolor: "info" },
    ]
    const data = Object.keys(technologyCounts).map(technology => [
        technologyCounts[technology]._id,
        technologyCounts[technology].count
    ]);
    console.log(data)
    const data1 = Object.keys(codingCounts).map(coding => [
        codingCounts[coding]._id,
        codingCounts[coding].count
    ]);

    return (
        <React.Fragment>
            <Miniwidget reports={reports} />
            <div className="Graph_division_1">
                <Card className="Graph_division_2">
                    <CardBody>
                        <h4 className="card-title mb-4">College Wise Analysis</h4>
                        <Row className="text-center mt-4">
                            <Col sm="4">
                                <h5 className="mb-0 font-size-20"><CountUp end={100} /></h5>
                                <p className="text-muted">AEC</p>
                            </Col>
                            <Col sm="4">
                                <h5 className="mb-0 font-size-20"><CountUp end={50} /></h5>
                                <p className="text-muted">ACET</p>
                            </Col>
                            <Col sm="4">
                                <h5 className="mb-0 font-size-20"><CountUp end={50} /></h5>
                                <p className="text-muted">ACOE</p>
                            </Col>
                        </Row>
                        <div dir="ltr">
                            <MyChart />
                        </div>
                    </CardBody>
                </Card>

            </div>
            <div className="Pie_Charts">
                <div className="Pie_Charts_1">
                    <Card className="m-b-20">
                        <CardBody>

                            <b><h3 className="card-title mb-4">Placement Division Based On The Technology</h3></b>
                            <h5>Tech Division</h5>

                            {/* <div className="row text-center mt-4">
                                <div className="col-sm-4">
                                    <h5 className="mb-0 font-size-20">86541</h5>
                                    <p className="text-muted">Activated</p>
                                </div>
                                <div className="col-sm-4">
                                    <h5 className="mb-0 font-size-20">2541</h5>
                                    <p className="text-muted">Pending</p>
                                </div>
                                <div className="col-sm-4">
                                    <h5 className="mb-0 font-size-20">102030</h5>
                                    <p className="text-muted">Deactivated</p>
                                </div>
                            </div> */}

                            <div id="pie-chart" dir="ltr">
                                <PieChart Info={data} />
                            </div>
                        </CardBody>
                    </Card>
                </div>
                <div className="Pie_Charts_1">
                    <Card className="m-b-20">
                        <CardBody>

                            <h4 className="card-title mb-4">Placement Division Based On Programming Language</h4>
                            <h5>Programme Language Division</h5>


                            {/* <div className="row text-center mt-4">
                                <div className="col-sm-4">
                                    <h5 className="mb-0 font-size-20">86541</h5>
                                    <p className="text-muted">Activated</p>
                                </div>
                                <div className="col-sm-4">
                                    <h5 className="mb-0 font-size-20">2541</h5>
                                    <p className="text-muted">Pending</p>
                                </div>
                                <div className="col-sm-4">
                                    <h5 className="mb-0 font-size-20">102030</h5>
                                    <p className="text-muted">Deactivated</p>
                                </div>
                            </div> */}

                            <div id="pie-chart" dir="ltr">
                                <PieChart Info={data1} />
                            </div>

                        </CardBody>
                    </Card>
                </div>

            </div>





        </React.Fragment>
    )
}

export default connect(null, { setBreadcrumbItems })(Admindashboard);