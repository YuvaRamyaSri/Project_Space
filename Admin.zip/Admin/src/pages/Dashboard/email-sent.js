import React, { Component } from 'react';
import { Row, Col, Card, CardBody } from "reactstrap";
import ReactApexChart from 'react-apexcharts';

class MonthlyEarnings extends Component {
    constructor(props) {
        super(props);

        this.state = {
            options: {
                colors: ['#ccc', '#7a6fbe', 'rgb(40, 187, 227)'],
                chart: {
                    toolbar: {
                        show: !1,
                    },
                },
                dataLabels: {
                    enabled: !1
                },
                stroke: {
                    curve: 'smooth',
                    width: 0.1,
                },
                grid: {
                    borderColor: '#f8f8fa',
                    row: {
                        colors: ['transparent', 'transparent'],
                        opacity: 0.5
                    },
                },
                xaxis: {
                    categories: ['CSE', 'IT', 'ECE', 'MECH', 'EEE', 'AIDS', 'AIML'],
                    axisBorder: {
                        show: !1
                    },
                    axisTicks: {
                        show: !1
                    }
                },
                yaxis: {
                    min: 0,
                    max: 50,
                    tickAmount: 6, // Adjust the number of ticks as needed
                    labels: {
                        formatter: function (val) {
                            return val.toFixed(0) ;
                        }
                    }
                },
                legend: {
                    show: !1
                },
            },
            series: [
                {
                    name: 'Series A',
                    data: [4, 10, 18, 6, 19, 12, 4]
                },
                {
                    name: 'Series B',
                    data: [3, 13, 23, 15, 16, 33,3]
                },
                {
                    name: 'Series C',
                    data: [0, 15, 19, 21, 33, 22, 0]
                }
            ],
        }
    }
    render() {
        return (
            <React.Fragment>
                <Card>
                    <CardBody>
                        <h4 className="card-title mb-4">Email Sent</h4>

                        <Row className="text-center mt-4">
                            <Col xs="4">
                                <p className="text-muted">Department</p>
                            </Col>
                            <Col xs="4">
                                <h5 className="font-size-20">33.33LPA</h5>
                                <p className="text-muted">Package</p>
                            </Col>
                            <Col xs="4">
                                <h5 className="font-size-20">2024-2025</h5>
                                <p className="text-muted">Current year</p>
                            </Col>
                        </Row>

                        <div id="morris-area-example" className="morris-charts morris-charts-height" dir="ltr">
                            <ReactApexChart options={this.state.options} series={this.state.series} type="area" height="300" />
                        </div>
                    </CardBody>
                </Card>
            </React.Fragment>
        );
    }
}

export default MonthlyEarnings;
