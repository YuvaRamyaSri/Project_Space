import React, { useState, useEffect } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Alert,
  CardBody,
  Button,
  Label,
  Input,
  FormFeedback,
  Form,
} from "reactstrap";
import axios from "axios";
import * as Yup from "yup";
import { useFormik } from "formik";
import { useSelector, useDispatch } from "react-redux";
import { createSelector } from "reselect";
import withRouter from "components/Common/withRouter";

import user1 from "../../assets/images/users/user-1.jpg";
import { editProfile } from "../../store/auth/profile/actions";

const UserProfile = () => {
  document.title = "Profile | Skote - React Admin & Dashboard Template";

  const dispatch = useDispatch();
  const rollNo = localStorage.getItem('rollno');
  const [userData, setUserData] = useState({});
  const [error, setError] = useState("");

  const selectProfileState = (state) => state.Profile;
  const ProfileProperties = createSelector(
    selectProfileState,
    (profile) => ({
      error: profile.error,
      success: profile.success,
    })
  );

  const { success } = useSelector(ProfileProperties);

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/user/profile/${rollNo}`);
        const userData = response.data;
        setUserData(userData);
      } catch (error) {
        console.error('Error fetching user profile:', error);
        setError('Failed to fetch user profile');
      }
    };

    fetchUserProfile();

  }, [dispatch, rollNo, success]);

  const validation = useFormik({
    enableReinitialize: true,
    initialValues: {
      username: userData.name || '',
      college: userData.college || '',
      idx: userData.idx || '',
    },
    validationSchema: Yup.object({
      username: Yup.string().required("Please Enter Your UserName"),
      college: Yup.string().required("Please Enter Your College"),
    }),
    onSubmit: (values) => {
      dispatch(editProfile(values));
    }
  });

  return (
    <React.Fragment>
      <div className="page-content p-0">
        <Container fluid>
          <Row>
            <Col lg="12">
              {error && <Alert color="danger">{error}</Alert>}
              <Card>
                <CardBody>
                  <div className="d-flex">
                    <div className="ms-3">
                      <img
                        src={user1}
                        alt=""
                        className="avatar-md rounded-circle img-thumbnail"
                      />
                    </div>
                    <div className="flex-grow-1 align-self-center">
                      <div className="text-muted">
                        <h5>{userData.name}</h5>
                        <p className="mb-1">{userData.email}</p>
                        <p className="mb-1">College: {userData.college}</p>
                        <p className="mb-0">Id no: #{userData.idx}</p>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <h4 className="card-title mb-4">Update Profile</h4>
          <Card>
            <CardBody>
              <Form
                className="form-horizontal"
                onSubmit={validation.handleSubmit}
              >
                <div className="form-group">
                  <Label className="form-label">User Name</Label>
                  <Input
                    name="username"
                    className="form-control"
                    placeholder="Enter User Name"
                    type="text"
                    onChange={validation.handleChange}
                    onBlur={validation.handleBlur}
                    value={validation.values.username || ""}
                    invalid={validation.touched.username && !!validation.errors.username}
                  />
                  {validation.touched.username && validation.errors.username && (
                    <FormFeedback type="invalid">
                      {validation.errors.username}
                    </FormFeedback>
                  )}
                  <Input name="idx" value={userData.idx} type="hidden" />
                </div>
                <div className="form-group">
                  <Label className="form-label">College</Label>
                  <Input
                    name="college"
                    className="form-control"
                    placeholder="Enter College"
                    type="text"
                    onChange={validation.handleChange}
                    onBlur={validation.handleBlur}
                    value={validation.values.college || ""}
                    invalid={validation.touched.college && !!validation.errors.college}
                  />
                  {validation.touched.college && validation.errors.college && (
                    <FormFeedback type="invalid">
                      {validation.errors.college}
                    </FormFeedback>
                  )}
                </div>
                <div className="text-center mt-4">
                  <Button type="submit" color="danger">
                    Update Profile
                  </Button>
                </div>
              </Form>
            </CardBody>
          </Card>
        </Container>
      </div>
    </React.Fragment>
  );
};

export default withRouter(UserProfile);
