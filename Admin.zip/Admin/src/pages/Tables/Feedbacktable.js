import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './feedback.css';
import { MDBDataTable } from 'mdbreact';
import { Row, Col, Card, CardBody, CardTitle } from 'reactstrap';

const SentimentAnalysisResult = () => {
  const [feedbackData, setFeedbackData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/feedbacktable');
        setFeedbackData(response.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const columns = [
    {
      label: "Name",
      field: "name",
      sort: "asc",
      width: 150,
    },
    {
      label: "Roll No",
      field: "rollNo",
      width: 150,
    },
    {
      label: "Company",
      field: "company",
      width: 200,
    },
    {
      label: "Role",
      field: "role",
      width: 150,
    },
    {
      label: "Experience",
      field: "experience",
      width: 150,
    },
    {
      label: "Feedback",
      field: "feedback",
      width: 150,
    },
    {
      lable:"Sentiment",
      field:"sentiment",
      width:150,
    },
  ];

  // Preprocess the data and add custom styles
  const formattedData = feedbackData.map((student) => {
    let row = {
      name: student.name,
      rollNo: student.rollNo,
      company: student.company,
      role: student.role,
      experience: student.experience,
      feedback: student.feedback,
      sentiment: student.sentiment,
    };

    // Add custom className based on sentiment
    switch (student.sentiment) {
      case 'positive':
        row.className = 'positive-row';
        break;
      case 'negative':
        row.className = 'negative-row';
        break;
      case 'neutral':
        row.className = 'neutral-row';
        break;
      default:
        break;
    }

    return row;
  });

  const data = {
    columns: columns,
    rows: formattedData,
  };

  return (
    <React.Fragment>
      <Row>
        <Col className="col-12">
          <Card>
            <CardBody>
              <CardTitle className="h4">Total Students</CardTitle>
              <MDBDataTable responsive bordered data={data} />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default SentimentAnalysisResult;
