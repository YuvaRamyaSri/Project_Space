import React, { useEffect, useState } from "react";
import { MDBDataTable } from "mdbreact";
import { Row, Col, Card, CardBody, CardTitle } from "reactstrap";
import { connect } from "react-redux";
import { setBreadcrumbItems } from "../../store/actions";
import axios from "axios";

const ResponsiveTable = (props) => {
  document.title = "Placed Students | Lexa - Responsive Bootstrap 5 Admin Dashboard";

  const breadcrumbItems = [
    { title: "Lexa", link: "#" },
    { title: "Tables", link: "#" },
    { title: "Placed Students", link: "#" },
  ];

  useEffect(() => {
    props.setBreadcrumbItems("Placed Students", breadcrumbItems);
  }, []);

  const [placedStudents, setPlacedStudents] = useState([]);

  useEffect(() => {
    async function fetchPlacedStudents() {
      try {
        const response = await axios.get("http://localhost:5000/placedstudents");
        const responses = response.data;
        setPlacedStudents(responses);
      } catch (error) {
        console.error("Error fetching placed students:", error);
      }
    }

    fetchPlacedStudents();
  }, []);

  const columns = [
    {
      label: "Student Name",
      field: "student_name",
      sort: "asc",
      width: 150,
    },
    {
      label: "Roll No",
      field: "roll_no",
      width: 150,
    },
    {
      label: "College",
      field: "college",
      width: 200,
    },
    {
      label: "Branch",
      field: "branch",
      width: 150,
    },
    // {
    //   label: "Placement Count",
    //   field: "Placement_count",
    //   width: 150,
    // },
    {
      label: "Email",
      field: "email",
      width: 200,
    },
    {
      label: "Company",
      field: "Company",
      width: 150,
    },
    {
      label: "Roll",
      field: "Roll",
      width: 150,
    },
    {
      label: "Package",
      field: "Package",
      width: 150,
    },
    {
      label: "Technology",
      field: "Technology",
      width: 150,
    },
  ];

  const data = {
    columns: columns,
    rows: placedStudents.map((student) => ({
      ...student,
      roll_no: student.roll_no,
      student_name: student.student_name,
      college: student.college,
      branch: student.branch,
      // Placement_count: student.Placement_count,
      email: student.email,
      Company: student.Company,
      Roll: student.Roll,
      Package: student.Package,
      Technology:student.Technology
    })),
  };

  return (
    <React.Fragment>
      <Row>
        <Col className="col-12">
          <Card>
            <CardBody>
              <CardTitle className="h4">Placed Students</CardTitle>
              <MDBDataTable responsive bordered data={data} />
            </CardBody>
          </Card>
        </Col>
      </Row>
    </React.Fragment>
  );
};

export default connect(null, { setBreadcrumbItems })(ResponsiveTable);
