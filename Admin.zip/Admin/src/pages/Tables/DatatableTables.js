import React, { useEffect, useState } from "react";
import { MDBDataTable } from "mdbreact";
import { Row, Col, Card, CardBody, CardTitle } from "reactstrap";
import { connect } from "react-redux";
import { setBreadcrumbItems } from "../../store/actions";
import {  Form, FormGroup, Label, Input } from "reactstrap";
import { Button } from "reactstrap";

import axios from "axios";
import { color } from "echarts";

const DatatableTables = (props) => {
  document.title = "Data Table | Lexa - Responsive Bootstrap 5 Admin Dashboard";

  const breadcrumbItems = [
    { title: "Lexa", link: "#" },
    { title: "Tables", link: "#" },
    { title: "Data Tables", link: "#" },
  ];

  useEffect(() => {
    props.setBreadcrumbItems("Data Tables", breadcrumbItems);
  }, []);

  const [students, setStudents] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    rollno: "",
    college: "",
    branch: "",
    email: ""
  });

  useEffect(() => {
    async function fetchStudents() {
      try {
        const response = await axios.get('http://localhost:5000/students');
        const responses = response.data;
        console.log(responses[0])
        setStudents(responses);
      } catch (error) {
        console.error("Error fetching students:", error);
      }
    }

    fetchStudents();
  }, []);
  const handleButtonClick = (student) => {
    setFormData({
      name: student.student_name,
      rollno: student.roll_no,
      college: student.college,
      branch: student.branch,
      email: student.email
    });
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/placedstudent', {
        roll_no: formData.rollno,
        student_name: formData.name,
        college: formData.college,
        branch: formData.branch,
        Placement_count: parseInt(formData.Placement_count),
        email: formData.email,
        Company: formData.Company,
        Roll: formData.Roll,
        Package: formData.Package,
        Technology:formData.Technology
      });
      // Clear form and hide form after successful submission
      setFormData({
        name: "",
        rollno: "",
        college: "",
        branch: "",
        Placement_count: 2,
        email: "",
        Company: "",
        Roll: "",
        Package: "",
        Technology:""
      });
      setShowForm(false);
    } catch (error) {
      console.error("Error adding placement:", error);
    }
  };
  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const columns = [
    {
      label: "Student Name",
      field: "student_name",
      sort: "asc",
      width: 150,
    },
    {
      label: "Roll No",
      field: "roll_no",
      width: 150,
    },
    {
      label: "College",
      field: "college",
      width: 200,
    },
    {
      label: "Branch",
      field: "branch",
      width: 150,
    },
    {
      label: "Passout Year",
      field: "passout_year",
      width: 150,
    },
    {
      label: "SSC Percentage",
      field: "ssc_percent",
      width: 150,
    },
    {
      label: "Inter Percentage",
      field: "inter_percent",
      width: 150,
    },
    {
      label: "B.Tech Percentage",
      field: "btech_percent",
      width: 150,
    },
    {
      label: "Backlogs",
      field: "backlogs",
      width: 150,
    },
    // {
    //   label: "Gender",
    //   field: "gender",
    //   width: 150,
    // },
    {
      label: "Email",
      field: "email",
      width: 200,
    },
    {
      label: "Actions",
      field: "actions",
      width: 200,
      sort: false,
    }
  ];

  const data = {
    columns: columns,
    rows: students.map((student) => ({
      ...student,
      roll_no: student.roll_no,
      student_name: student.student_name,
      college: student.college,
      branch: student.branch,
      passout_year: student.passout_year,
      ssc_percent: student.ssc_percent,
      inter_percent: student.inter_percent,
      btech_percent: student.btech_percent,
      backlogs: student.backlogs,
      // gender: student.gender,
      email: student.email,
      actions: (
        <Button color="success" size="sm" onClick={() => handleButtonClick(student)}>
         Add Placement
        </Button>
      )
    })),
  };

  return (
    <React.Fragment>
      <Row>
        <Col className="col-12">
          <Card>
            <CardBody>
              <CardTitle className="h4">Total Students</CardTitle>
              <MDBDataTable responsive bordered data={data} />
            </CardBody>
          </Card>
        </Col>
      </Row>
      {showForm && (
        <Row>
          <Col className="col-12">
            <Card>
              <CardBody>
                <CardTitle className="h4">Add Placement</CardTitle>
                <FormGroup>
                  <Label for="studentName">Student Name</Label>
                  <Input type="text" id="studentName" value={formData.name} readOnly />
              </FormGroup>
              <FormGroup>
                <Label for="studentRoll">Roll</Label>
                <Input type="text" id="studentRoll" value={formData.rollno} readOnly />
              </FormGroup>
              <FormGroup>
                <Label for="studentCollege">College</Label>
                <Input type="text" id="studentCollege" value={formData.college} readOnly />
              </FormGroup>
              <FormGroup>
              <Label for="studentBranch">Branch</Label>
              <Input type="text" id="studentBranch" value={formData.branch} readOnly />
        </FormGroup>
                <Form onSubmit={handleSubmit}>
                  <FormGroup>
                    <Label for="company">Company</Label>
                    <Input type="text" name="Company" id="company" value={formData.Company} onChange={handleInputChange} required />
                  </FormGroup>
                  <FormGroup>
                    <Label for="roll">Roll</Label>
                    <Input type="text" name="Roll" id="roll" value={formData.Roll} onChange={handleInputChange} required />
                  </FormGroup>
                  <FormGroup>
                    <Label for="package">Package</Label>
                    <Input type="number" name="Package" id="package" value={formData.Package} onChange={handleInputChange} required />
                  </FormGroup>
                  <FormGroup>
                    <Label for="package">Technology</Label>
                    <Input type="text" name="Technology" id="technology" value={formData.Technology} onChange={handleInputChange} required />
                  </FormGroup>
                  <Button color="primary" type="submit">Submit</Button>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>)}
         {/* <Row>
            <Col className="col-12">
              <Card>
                <CardBody>
                  <CardTitle className="h4">Stripped example </CardTitle>
                  <p className="card-title-desc">
                    mdbreact DataTables has most features enabled by default, so
                    all you need to do to use it with your own tables is to call
                    the construction function:{" "}
                    <code>&lt;MDBDataTable striped /&gt;</code>.
                  </p>

                  <MDBDataTable responsive striped bordered data={data} />
                </CardBody>
              </Card>
            </Col>
          </Row> */}
    </React.Fragment>
  );
};



export default connect(null, { setBreadcrumbItems })(DatatableTables);