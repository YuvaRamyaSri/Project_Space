import React, { useState } from 'react';
import axios from 'axios';
import './apii.css';

const AzureSentimentAnalysis = () => {
    const [formData, setFormData] = useState({
        name: '',
        rollNo: '',
        company: '',
        role: '',
        experience: '',
        feedback: ''
    });
    const [sentiment, setSentiment] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        alert("Submitted Successfuly")
        try {
            const response = await axios.post(
                'http://localhost:5000/feedback', // Update with your backend endpoint
                {
                    ...formData,
                    sentiment: sentiment // Add sentiment to form data
                }
            );
            console.log('Feedback submitted:', response.data);
        } catch (error) {
            console.error('Error submitting feedback:', error);
        }
    };

    const analyzeSentiment = async () => {
        try {
            const response = await axios.post(
                'https://eastus.api.cognitive.microsoft.com/text/analytics/v3.0/sentiment',
                {
                    documents: [
                        {
                            id: '1',
                            text: formData.feedback, // Analyze sentiment of feedback text
                        },
                    ],
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        'Ocp-Apim-Subscription-Key': '9f54ecd90376405587302221386854f8',
                    },
                }
            );
            if (response.data && response.data.documents && response.data.documents[0]) {
                const sentiment = response.data.documents[0].sentiment;
                console.log('Sentiment:', sentiment);
                setSentiment(sentiment);
            } else {
                console.error('Invalid response data format:', response.data);
            }
        } catch (error) {
            console.error('Error analyzing sentiment:', error);
        }
    };

    return (
        <div className="container">
            <h2>Azure Sentiment Analysis</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="text" name="name" value={formData.name} onChange={handleChange} required />
                </div>
                <div>
                    <label>Roll No:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="text" name="rollNo" value={formData.rollNo} onChange={handleChange} required />
                </div>
                <div>
                    <label>Company:</label>&nbsp;&nbsp;
                    <input type="text" name="company" value={formData.company} onChange={handleChange} required />
                </div>
                <div>
                    <label>Role:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="text" name="role" value={formData.role} onChange={handleChange} required />
                </div>
                <div>
                    <label>Experience:</label>&nbsp;&nbsp;
                    <input type="text" name="experience" value={formData.experience} onChange={handleChange} required />
                </div>
                <div>
                    <label>Feedback:</label>&nbsp;&nbsp;
                    <textarea name="feedback" value={formData.feedback} onChange={handleChange} required></textarea>
                </div>
                <br />
                <button className="button" onClick={analyzeSentiment}>
                Submit Feedback
                </button>
            </form>
            {sentiment && (
                <div className="sentiment">
                    <h3>Sentiment: {sentiment}</h3>
                </div>
            )}
        </div>
    );
};

export default AzureSentimentAnalysis;
