const mongoose = require('mongoose');
const DB_Url = "mongodb://127.0.0.1:27017/local";
const express = require('express');
const Feedback = require('./feedbackModel');
const Company = require('./CompanyModel');
const app = express();
app.use(express.json());
mongoose.connect(DB_Url);
const conn = mongoose.connection;
conn.once('open',()=>{
    console.log('Successfully connected to database');
})
conn.on('error',(error)=>{
    console.log(`Failed to connect ${error.message}`);
})

const cors = require('cors');
app.use(cors());



const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); // Specify the directory where uploaded images will be stored

app.post('/api/postData', upload.single('logo'), async (req, res) => {
  try {
    const {
      CompanyName,
      description,
      eligibility,
      packageoffered,
      applied,
      role
    } = req.body;

    // Construct the logoUrl using the filename provided by multer
    const logoUrl = req.file ? req.file.filename : null;

    // Create a new company instance using the Company model
    const newCompany = new Company({
      logoUrl,
      CompanyName,
      description,
      eligibility,
      packageoffered,
      applied,
      role
    });

    // Save the new company to the database
    await newCompany.save();

    // Respond with success message
    res.status(201).json({ message: 'Company added successfully' });
  } catch (error) {
    console.error('Error adding company:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Access the collection directly without defining a schema
const studentsCollection = conn.collection('students_data');
const placementCollection = conn.collection('student');
app.get('/students', async (req, res) => {
    try {
      // Retrieve student data from the collection
      const students = await studentsCollection.find().toArray();
      res.json(students); // Send the retrieved data as JSON response
    } catch (error) {
      console.error('Error retrieving student data:', error);
      res.status(500).json({ error: 'Internal server error' }); // Send an error response
    }
  });




  app.get('/placedstudents', async (req, res) => {
    try {
      // Retrieve student data from the collection
      const student = await placementCollection.find().toArray();
      res.json(student); // Send the retrieved data as JSON response
    } catch (error) {
      console.error('Error retrieving student data:', error);
      res.status(500).json({ error: 'Internal server error' }); // Send an error response
    }
  });

  app.get('/totalcount', async (req, res) => {
    try {
        // Retrieve total placements count
        const totalCount = await placementCollection.countDocuments();

        // Retrieve highest package value
        const highestPackageResult = await placementCollection.aggregate([
          { $match: { Package: { $exists: true, $ne: null } } },
          { $group: { _id: null, maxPackage: { $max: { $toDouble: "$Package" } } } }
      ]).toArray();

        // Extract the numeric value of the highest package
        const highestPackage = highestPackageResult.length > 0 ? highestPackageResult[0].maxPackage : 0;

        // Log for debugging
        console.log("Highest Package Result:", highestPackageResult);
        console.log("Highest Package:", highestPackage);

        res.json({ totalPlacements: totalCount, highestPackage: highestPackage });
    } catch (error) {
        console.error('Error retrieving placement information:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});






  app.post('/placedstudent', async (req, res) => {
    try {
      const {  roll_no, student_name, college, branch, Placement_count, email, Company, Roll, Package ,Technology} = req.body;

      // Insert placement data into the collection
      await placementCollection.insertOne({
        roll_no,
        student_name,
        college,
        branch,
        Placement_count,
        email,
        Company,
        Roll,
        Package,
        Technology

      });
      // Respond with success message
      res.status(201).json({ message: 'Placement added successfully' });
    } catch (error) {
      console.error('Error adding placement:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  

  app.get('/technologyCount', async (req, res) => {
    try {
        // Find the count of placements for each technology
        const technologyCounts = await placementCollection.aggregate([
            { $match: { Technology: { $in: ["FSD", "AWS Cloud", "Azure Cloud", "Google Cloud"] } } },
            { $group: { _id: "$Technology", count: { $sum: 1 } } }
        ]).toArray();

        // Log for debugging
        // console.log("Technology Counts:", technologyCounts.count);

        res.json(technologyCounts);
    } catch (error) {
        console.error('Error retrieving technology counts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/technologyCountsSeparate', async (req, res) => {
  try {
      // Find the count of placements for each technology separately
      const technologyCountts = await placementCollection.aggregate([
          { $match: { Technology: { $in: ["C++", "Python", "Java"] } } },
          {
              $group: {
                  _id: "$Technology",
                  count: { $sum: 1 }
              }
          }
      ]).toArray();

      res.json(technologyCountts);
  } catch (error) {
      console.error('Error retrieving separate technology counts:', error);
      res.status(500).json({ error: 'Internal server error' });
  }
});



// Import the Feedback model
// GET route to retrieve feedback
app.get('/feedbacktable', async (req, res) => {
  try {
      // Retrieve feedback data from the Feedback collection
      const feedback = await Feedback.find();
      res.json(feedback); // Send the retrieved data as JSON response
  } catch (error) {
      console.error('Error retrieving feedback:', error);
      res.status(500).json({ error: 'Internal server error' }); // Send an error response
  }
});

// POST route for saving feedback
app.post('/feedback', async (req, res) => {
    try {
        const { name, rollNo, company, role, experience, feedback, sentiment } = req.body;

        // Create a new feedback document using the Feedback model
        const newFeedback = new Feedback({
            name,
            rollNo,
            company,
            role,
            experience,
            feedback,
            sentiment
        });

        // Save the feedback to the database
        await newFeedback.save();

        res.status(201).json({ message: 'Feedback submitted successfully' });
    } catch (error) {
        console.error('Error submitting feedback:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


app.get('/companyStats', async (req, res) => {
  try {
      const totalCompanies = await placementCollection.distinct('Company').length;

      const mostCommonCompany = await placementCollection.aggregate([
          { $group: { _id: "$Company", count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 1 }
      ]).toArray();
      console.log(totalCompanies, mostCommonCompany)
      res.json({ totalCompanies, mostCommonCompany });
  } catch (error) {
      console.error('Error retrieving company stats:', error);
      res.status(500).json({ error: 'Internal server error' });
  }
});



  app.get('/api/user/profile/:rollno', async (req, res) => {
    try {
        const rollNo = req.params.rollno;
        console.log(rollNo)
        const user = await studentsCollection.findOne({ roll_no: rollNo });
        if (!user) {
          return res.status(404).json({ error: 'User not found' });
      }
        console.log(user)
      // Send the user's profile data to the frontend
      res.status(200).json(user);
  } catch (error) {
      console.error('Error retrieving user profile:', error);
      res.status(500).json({ error: 'Internal server error' });
  }
});



  app.post('/loginn', async (req, res) => {
    const { email, password } = req.body;

    try {
      const students = await studentsCollection.find().toArray();
      // Check if the provided email exists in your student data
      const user = students.find(student => student.email === email);

      if (!user && user.email!="1") {
        return res.status(401).send("Invalid email or password");
      }

      // Compare the provided password with the fixed password
      if (password !== 'Aditya@123') {
        return res.status(401).send("Invalid email or password");
      }

      // Authentication successful
      res.status(200).send("Authentication successful");
    } catch (error) {
      console.error(error);
      res.status(500).send("Error logging in");
    }
  });

app.listen(5000);
