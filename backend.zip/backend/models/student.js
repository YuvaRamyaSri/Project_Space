const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId,
  id: { type: Number, required: true },
  roll_no: { type: String, required: true },
  student_name: { type: String, required: true },
  college: { type: String, required: true },
  branch: { type: String, required: true },
  passout_year: { type: Number, required: true },
  ssc_percent: { type: Number, required: true },
  inter_percent: { type: Number, required: true },
  btech_percent: { type: Number, required: true },
  backlogs: { type: Number, required: true },
  gender: { type: String, required: true },
  email: { type: String, required: true }
});
module.exports = studentSchema;
