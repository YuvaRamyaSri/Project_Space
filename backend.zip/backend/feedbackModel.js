// feedbackModel.js

const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema({
    name: { type: String, required: true },
    rollNo: { type: String, required: true },
    company: { type: String, required: true },
    role: { type: String, required: true },
    experience: { type: String, required: true },
    feedback: { type: String, required: true },
    sentiment: { type: String, required: true }
});

module.exports = mongoose.model('Feedback', feedbackSchema);
