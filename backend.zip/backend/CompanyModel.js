const mongoose = require('mongoose');

const companySchema = new mongoose.Schema({
    logoUrl: String,
    CompanyName: String,
    description: String,
    eligibility: String,
    packageoffered: String,
    applied: String,
    role: String
});

const Company = mongoose.model('company', companySchema);

module.exports = Company;
